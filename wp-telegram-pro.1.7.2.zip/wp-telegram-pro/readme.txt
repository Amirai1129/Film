=== WP Telegram Pro ===
Contributors: parselearn
Donate link: https://parsa.ws
Tags: telegram, woocommerce, bot, robot, channel, notifications
Requires at least: 5.0
Tested up to: 5.2.2
Stable tag: 1.7.2
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate WordPress with Telegram

== Description ==

**Integrate WordPress with Telegram**

* New comments notification
* Search in post types
* Send post automatically to Telegram channel
* Integrate with Woocommerce
* Display Telegram channel members count with shortcode.

**Translate**

* [Kurdish](https://translate.wordpress.org/locale/ckb/default/wp-plugins/wp-telegram-pro/) (Thanks [@qezwan](https://profiles.wordpress.org/qezwan/))
* [Persian](https://translate.wordpress.org/locale/fa/default/wp-plugins/wp-telegram-pro/)

[Proxy mode base on WP Telegram](https://wordpress.org/plugins/wptelegram/)

== Frequently Asked Questions ==

= How to create a Telegram Bot =
[How do I create a bot?](https://core.telegram.org/bots/faq#how-do-i-create-a-bot).

= How to display Telegram channel members count =
With channel_members_wptp shortcode: `[channel_members_wptp channel="channel username" formatting="1"]`
For example: `[channel_members_wptp channel="telegram" formatting="1"]`

== Screenshots ==

1. Basic Settings
2. Channel Settings
3. Woocommerce Settings
4. Proxy Settings
5. Helps page
5. Debugs page

== Changelog ==
= 1.7.2 2019-08-24 =
* Fixed some bugs in PHP5.*

= 1.7.1 2019-07-25 =
* Add host info (IP/Location) to debugs page
* Fixed some bugs

= 1.7 2019-07-21 =
* Add debugs page
* Add helps page
* Cleans post excerpt from tags and unused shortcodes

= 1.6 2019-06-04 =
* New option for display channels metabox base on user role
* Add currency symbol to channel pattern tags, `{currency-symbol}`
* Fixed some bugs

= 1.5 2019-05-12 =
* Inline button for channel message
* Fixed some bugs

= 1.4 2019-05-02 =
* Delay time to send channels
* Fixed some bugs

= 1.3 2019-04-22 =
* Add proxy settings

= 1.2 2019-04-13 =
* Compatible with RTL languages
* Add custom field and terms to pattern tags
* Add if statement to pattern tags
* Admin can force update telegram keyboard

= 1.1 2019-04-06 =
* Add channel_members_wptp shortcode for display Telegram channel members count.


 == Upgrade Notice ==
